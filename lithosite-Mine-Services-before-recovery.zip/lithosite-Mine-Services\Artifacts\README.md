# Artifacts

This folder contains the canonical active UI entry point.

- Active artifact: `Mine-Services-Operations.html`
- Desktop Host and launcher must resolve this entry point.
- Do not add version-specific or stage-specific copies to the active Artifacts folder.
- Historical version lineage and release evidence belong under `Documentation/Version-History/`.

<<<<<<< HEAD
- `Mine-Services-Concept-2-Dashboard-Operations-v40-STAGE29.html`
  - Active Stage 29 working artifact on `v40-workspace`.
  - Copied from the locked V39 / Stage 28 baseline.
  - New UI and layout changes belong to this artifact while V40 is in progress.

## Locked baseline

- `Mine-Services-Concept-2-Dashboard-Operations-v39-STAGE28.html`
  - Locked V39 / Stage 28 baseline.
  - Reference and rollback only; do not edit it as part of V40 workspace work.

V38 and earlier versioned artifacts are historical. They are not active V40 entry points.

Authoritative contracts and test plans remain under `Documentation/`; the A3 database remains under `Database/`.
=======
The canonical A.3 database remains under `Database/`.
>>>>>>> f3762ae835475db05f7ba209a1c76b0f24c3dc5a
