# Testing

Mine Services test strategy, matrices, audits, and verification records.

<<<<<<< HEAD
- [V40 Work Control Plan vs Actual Integration Plan](./V40-Work-Control-Plan-vs-Actual-Integration-Plan.md) — source mapping, metric contract, implementation sequence, and required tests for the initial V40 dashboard backlog.

- `test_v40_dashboard_plan_actual.py` — V40 Work Control Plan vs Actual integration contract and regression guards.
=======
- [V40 Work Control Plan vs Actual Integration Plan](./V40-Work-Control-Plan-vs-Actual-Integration-Plan.md) — historical implementation context; current business semantics remain on global HOLD.

- `test_dashboard_plan_actual.py` — initial dialog contract and regression guards.

- [V40 Desktop Runtime Acceptance — Operational A3](./V40-Desktop-Runtime-A3-Acceptance.md) — local-only read-only acceptance steps for the operational A3 workbook; explicitly separate from the isolated CI fixture.
>>>>>>> f3762ae835475db05f7ba209a1c76b0f24c3dc5a
