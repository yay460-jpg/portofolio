/*
 * Lithosite Shared Topo3D Engine
 * Source baseline: Offline DTM 3D Viewer V23.2 supplied by project.
 * UI-independent: no document IDs, no Member/Master layout, no global singleton state.
 * One engine instance owns one canvas + one WebGL context + one terrain model.
 */
(function(global){
  'use strict';

  function nextFrame(){ return new Promise(function(r){ requestAnimationFrame(function(){ requestAnimationFrame(r); }); }); }

  // Resource guard: reject oversized/corrupt terrain before expensive geometry/GPU allocations.
  var TOPO3D_RESOURCE_LIMITS={
    maxDtmBytes:64*1024*1024,
    maxStrBytes:64*1024*1024,
    maxPackageBytes:128*1024*1024,
    maxVertices:300000,
    maxTriangles:600000
  };

  function guardTopoFileSize_(file,maxBytes,label){
    if(!file||typeof file.size!=='number')throw new Error(label+' tidak dapat divalidasi.');
    if(file.size>maxBytes)throw new Error(label+' terlalu besar. Batas '+Math.round(maxBytes/1048576)+' MB.');
  }

  function guardTopoCount_(count,max,label){
    if(count>max)throw new Error(label+' melebihi batas Topo3D ('+max.toLocaleString('id-ID')+').');
  }

  function Topo3DEngine(options){
    options=options||{};
    this.canvas=options.canvas||null;
    this.onStatus=typeof options.onStatus==='function'?options.onStatus:function(){};this.onRender=typeof options.onRender==='function'?options.onRender:function(){};
    this.onReady=typeof options.onReady==='function'?options.onReady:function(){};
    this.onError=typeof options.onError==='function'?options.onError:function(){};
    this.gl=null; this.indexType=null; this.prog=null; this.loc={};
    this.pb=null; this.nb=null; this.ab=null; this.ib=null; this.wb=null;
    this.ic=0; this.wireIdx=null; this.model=null; this.raf=null; this.prepared=false; this.destroyed=false; this._sourcePackage=null;
    this.angleX=.44; this.angleY=-.38; this.zoom=1; this.panX=0; this.panY=0; this.view='3d';
    this.zFactor=1.10; this.gapGuard=true; this.meshOverlay=false; this.reliefStrength=.10; this.meshAlpha=.12; this.mode='shaded';
    this.reliefOn=true; this.tintOn=false; this.smoothStrength=0; this.smoothIterations=1; this.smoothBusy=false; this.aoStrength=.28;
    this.activePointers=new Map(); this.pinchStart=0; this.pinchZoom=1; this.dragging=false; this.lastX=0; this.lastY=0;
    this._boundResize=this.resize.bind(this);
    this._boundPointerDown=this._pointerDown.bind(this); this._boundPointerMove=this._pointerMove.bind(this);
    this._boundPointerUp=this._pointerUp.bind(this); this._boundWheel=this._wheel.bind(this);
  }

  Topo3DEngine.prototype.prepare=async function(){
    if(this.prepared)return this;
    if(!this.canvas)throw new Error('Topo3D canvas tidak tersedia');
    this.onStatus('Menyiapkan WebGL…');
    this.gl=this.canvas.getContext('webgl2',{antialias:true,alpha:false});
    if(this.gl)this.indexType=this.gl.UNSIGNED_INT;
    else { this.gl=this.canvas.getContext('webgl',{antialias:true,alpha:false}); if(this.gl){var ext=this.gl.getExtension('OES_element_index_uint');if(ext)this.indexType=this.gl.UNSIGNED_INT;} }
    if(!this.gl||!this.indexType)throw new Error('WebGL2 / 32-bit index buffer tidak tersedia.');
    var gl=this.gl;
    var vs='attribute vec3 p;attribute vec3 n;attribute float a;uniform mat4 mvp;uniform mat4 model;uniform float meshOffset;uniform float zCenter;uniform float yScale;varying vec3 vN;varying float vH;varying float vZ;varying float vAO;void main(){vec3 P=p+n*meshOffset;vec4 W=model*vec4(P,1.0);vN=normalize(mat3(model)*n);vH=p.y;vZ=(p.y/max(yScale,0.00001))+zCenter;vAO=a;gl_Position=mvp*vec4(P,1.0);}';
    var fs='precision highp float;varying vec3 vN;varying float vH;varying float vZ;varying float vAO;uniform int mode;uniform int passType;uniform vec3 meshColor;uniform float reliefStrength;uniform float meshAlpha;uniform int reliefOn;uniform int tintOn;uniform float zMin;uniform float zMax;uniform float aoStrength;uniform int topView;void main(){vec3 N=normalize(vN);float t=clamp((vZ-zMin)/max(zMax-zMin,0.00001),0.,1.);if(passType==1){if(mode==2){vec3 c0=vec3(.18,.42,.72),c1=vec3(.34,.72,.76),c2=vec3(.96,.74,.28),c3=vec3(.86,.31,.18);vec3 c=t<.33?mix(c0,c1,t/.33):t<.68?mix(c1,c2,(t-.33)/.35):mix(c2,c3,(t-.68)/.32);gl_FragColor=vec4(c,meshAlpha);}else{gl_FragColor=vec4(meshColor,meshAlpha);}return;}vec3 key=topView==1?normalize(vec3(-.18,.76,-.64)):normalize(vec3(-.58,.72,.34));vec3 fillA=topView==1?normalize(vec3(.42,.78,-.46)):normalize(vec3(.45,.62,.64));vec3 fillB=topView==1?normalize(vec3(.66,.44,-.34)):normalize(vec3(.72,.38,.58));float keyL=max(dot(N,key),0.0);float fillL=max(dot(N,fillA),0.0);float bounceL=max(dot(N,fillB),0.0);float ambient=topView==1?.52:.34;float light=topView==1?.64*keyL+.20*fillL+.12*bounceL:.56*keyL+.14*fillL+.08*bounceL;float slope=1.0-clamp(N.y,0.0,1.0);float relief=mix(1.0,1.0-reliefStrength*(.025+.10*slope),float(reliefOn));vec3 base=vec3(.67,.47,.25);vec3 c0=vec3(.05,.22,.42),c1=vec3(.20,.48,.50),c2=vec3(.72,.61,.31),c3=vec3(.88,.43,.18);vec3 elev=t<.30?mix(c0,c1,t/.30):t<.68?mix(c1,c2,(t-.30)/.38):mix(c2,c3,(t-.68)/.32);vec3 c=(mode==1)?elev:((tintOn==1)?mix(base,elev,.07):base);float softSlope=1.0-smoothstep(.18,.72,N.y);float slopeCavity=smoothstep(.55,1.0,softSlope)*.035;float softAO=mix(1.0,0.76,vAO)*aoStrength+(1.0-aoStrength);vec3 lit=c*(ambient+light)*(1.0-slopeCavity)*softAO*relief;if(mode==1){float lv=(vZ-zMin)/5.0;float d=min(fract(lv),1.0-fract(lv));float contour=1.0-smoothstep(0.0,.018,d);float majorLv=(vZ-zMin)/25.0;float md=min(fract(majorLv),1.0-fract(majorLv));float major=1.0-smoothstep(0.0,.025,md);vec3 contourColor=vec3(.015,.035,.065);lit=mix(lit,contourColor,contour*.22+major*.10);}gl_FragColor=vec4(lit,1.0);}';
    function shader(type,src){var s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
    this.prog=gl.createProgram();gl.attachShader(this.prog,shader(gl.VERTEX_SHADER,vs));gl.attachShader(this.prog,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(this.prog);if(!gl.getProgramParameter(this.prog,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(this.prog));
    var p=this.prog;
    this.loc={p:gl.getAttribLocation(p,'p'),n:gl.getAttribLocation(p,'n'),a:gl.getAttribLocation(p,'a'),mvp:gl.getUniformLocation(p,'mvp'),model:gl.getUniformLocation(p,'model'),mode:gl.getUniformLocation(p,'mode'),meshOffset:gl.getUniformLocation(p,'meshOffset'),passType:gl.getUniformLocation(p,'passType'),meshColor:gl.getUniformLocation(p,'meshColor'),reliefStrength:gl.getUniformLocation(p,'reliefStrength'),meshAlpha:gl.getUniformLocation(p,'meshAlpha'),reliefOn:gl.getUniformLocation(p,'reliefOn'),aoStrength:gl.getUniformLocation(p,'aoStrength'),topView:gl.getUniformLocation(p,'topView'),tintOn:gl.getUniformLocation(p,'tintOn'),zMin:gl.getUniformLocation(p,'zMin'),zMax:gl.getUniformLocation(p,'zMax'),zCenter:gl.getUniformLocation(p,'zCenter'),yScale:gl.getUniformLocation(p,'yScale')};
    window.addEventListener('resize',this._boundResize); this.canvas.addEventListener('contextmenu',function(e){e.preventDefault();});
    this.canvas.addEventListener('pointerdown',this._boundPointerDown);this.canvas.addEventListener('pointermove',this._boundPointerMove);this.canvas.addEventListener('pointerup',this._boundPointerUp);this.canvas.addEventListener('pointercancel',this._boundPointerUp);this.canvas.addEventListener('wheel',this._boundWheel,{passive:false});
    this.prepared=true; this.resize(); this._startRender(); await nextFrame(); this.onStatus('WebGL siap. Menunggu data topografi…'); return this;
  };

  Topo3DEngine.prototype._startRender=function(){var self=this;function loop(){if(self.destroyed)return;self.render();self.raf=requestAnimationFrame(loop);}if(!this.raf)this.raf=requestAnimationFrame(loop);};
  Topo3DEngine.prototype.resize=function(){if(!this.gl||!this.canvas)return;var d=Math.min(global.devicePixelRatio||1,2),w=Math.max(1,Math.floor(this.canvas.clientWidth*d)),h=Math.max(1,Math.floor(this.canvas.clientHeight*d));if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;}this.gl.viewport(0,0,w,h);};
  Topo3DEngine.prototype._matMul=function(a,b){var o=new Float32Array(16);for(var c=0;c<4;c++)for(var r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o;};
  Topo3DEngine.prototype._ident=function(){var o=new Float32Array(16);o[0]=o[5]=o[10]=o[15]=1;return o;};
  Topo3DEngine.prototype._rx=function(a){var c=Math.cos(a),s=Math.sin(a),o=this._ident();o[5]=c;o[6]=s;o[9]=-s;o[10]=c;return o;};
  Topo3DEngine.prototype._ry=function(a){var c=Math.cos(a),s=Math.sin(a),o=this._ident();o[0]=c;o[2]=-s;o[8]=s;o[10]=c;return o;};
  Topo3DEngine.prototype._tr=function(x,y,z){var o=this._ident();o[12]=x;o[13]=y;o[14]=z;return o;};
  Topo3DEngine.prototype._sc=function(s){var o=this._ident();o[0]=o[5]=o[10]=s;return o;};
  Topo3DEngine.prototype._persp=function(fovy,asp,n,f){var t=1/Math.tan(fovy/2),o=new Float32Array(16);o[0]=t/asp;o[5]=t;o[10]=(f+n)/(n-f);o[11]=-1;o[14]=2*f*n/(n-f);return o;};
  Topo3DEngine.prototype.render=function(){if(!this.gl)return;this.resize();var gl=this.gl;gl.clearColor(0.02745098,0.04313725,0.10980392,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE);if(!this.model)return;var asp=this.canvas.width/Math.max(1,this.canvas.height),P=this._persp(.82,asp,.05,20),T=this._tr(this.panX,this.panY,-3.15),RX=this._rx(this.angleX),RY=this._ry(this.angleY),S=this._sc(this.zoom),M=this._matMul(T,this._matMul(this._matMul(RX,RY),S)),MVP=this._matMul(P,M),l=this.loc;gl.useProgram(this.prog);gl.uniformMatrix4fv(l.mvp,false,MVP);gl.uniformMatrix4fv(l.model,false,M);gl.uniform1i(l.mode,this.mode==='elevation'?1:(this.mode==='wire'?2:0));gl.uniform1i(l.passType,0);gl.uniform1f(l.meshOffset,0);gl.uniform1f(l.reliefStrength,this.reliefStrength);gl.uniform1f(l.meshAlpha,this.meshAlpha);gl.uniform1i(l.reliefOn,this.reliefOn?1:0);gl.uniform1f(l.aoStrength,this.aoStrength);gl.uniform1i(l.topView,this.view==='top'?1:0);gl.uniform1i(l.tintOn,this.tintOn?1:0);gl.uniform1f(l.zMin,this.model.meta.bounds.minZ);gl.uniform1f(l.zMax,this.model.meta.bounds.maxZ);var spanXY=Math.max(this.model.meta.bounds.maxX-this.model.meta.bounds.minX,this.model.meta.bounds.maxY-this.model.meta.bounds.minY)||1;gl.uniform1f(l.yScale,(1.65/spanXY)*this.zFactor);gl.uniform1f(l.zCenter,(this.model.meta.bounds.minZ+this.model.meta.bounds.maxZ)/2);gl.bindBuffer(gl.ARRAY_BUFFER,this.pb);gl.enableVertexAttribArray(l.p);gl.vertexAttribPointer(l.p,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,this.nb);gl.enableVertexAttribArray(l.n);gl.vertexAttribPointer(l.n,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,this.ab);gl.enableVertexAttribArray(l.a);gl.vertexAttribPointer(l.a,1,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.mode==='wire'?this.wb:this.ib);if(this.mode==='wire'){gl.uniform1i(l.passType,1);gl.uniform3f(l.meshColor,.90,.62,.18);gl.uniform1f(l.meshAlpha,Math.max(.35,this.meshAlpha));gl.uniform1f(l.meshOffset,.0015);gl.drawElements(gl.LINES,this.wireIdx.length,this.indexType,0);}else{gl.drawElements(gl.TRIANGLES,this.ic,this.indexType,0);if(this.meshOverlay){gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.uniform1i(l.passType,1);gl.uniform3f(l.meshColor,.10,.065,.025);gl.uniform1f(l.meshAlpha,this.meshAlpha);gl.uniform1f(l.meshOffset,.0018);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.wb);gl.drawElements(gl.LINES,this.wireIdx.length,this.indexType,0);gl.disable(gl.BLEND);}}this.onRender({view:this.view,angleX:this.angleX,angleY:this.angleY,zoom:this.zoom,panX:this.panX,panY:this.panY});};

  Topo3DEngine.prototype._buildNeighbors=function(n,idx){var sets=Array.from({length:n},function(){return new Set();});for(var i=0;i<idx.length;i+=3){var a=idx[i],b=idx[i+1],c=idx[i+2];sets[a].add(b);sets[a].add(c);sets[b].add(a);sets[b].add(c);sets[c].add(a);sets[c].add(b);}return sets.map(function(s){return Int32Array.from(s);});};
  Topo3DEngine.prototype._audit=function(xyz,idx){var edges=[],dzs=[],deg=0;for(var i=0;i<idx.length;i+=3){var a=idx[i]*3,b=idx[i+1]*3,c=idx[i+2]*3,ax=xyz[a],ay=xyz[a+1],az=xyz[a+2],bx=xyz[b],by=xyz[b+1],bz=xyz[b+2],cx=xyz[c],cy=xyz[c+1],cz=xyz[c+2];edges.push(Math.hypot(ax-bx,ay-by,az-bz),Math.hypot(bx-cx,by-cy,bz-cz),Math.hypot(cx-ax,cy-ay,cz-az));dzs.push(Math.abs(az-bz),Math.abs(bz-cz),Math.abs(cz-az));var ux=bx-ax,uy=by-ay,uz=bz-az,vx=cx-ax,vy=cy-ay,vz=cz-az,nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;if(Math.hypot(nx,ny,nz)<1e-9)deg++;}edges.sort(function(a,b){return a-b;});dzs.sort(function(a,b){return a-b;});function q(a,p){return a[Math.min(a.length-1,Math.floor((a.length-1)*p))]||0;}return {edgeP99:q(edges,.99),edgeMax:q(edges,1),dzMax:q(dzs,1),degenerate:deg};};
  Topo3DEngine.prototype._buildGPU=function(rawXYZ,indices,meta,reset){var n=rawXYZ.length/3,p99=meta.geometryAudit&&meta.geometryAudit.edgeP99||0,edgeLimit=this.gapGuard?Math.max(80,p99*6):Infinity,renderList=[];for(var i=0;i<indices.length;i+=3){var a=indices[i]*3,b=indices[i+1]*3,c=indices[i+2]*3,e1=Math.hypot(rawXYZ[a]-rawXYZ[b],rawXYZ[a+1]-rawXYZ[b+1]),e2=Math.hypot(rawXYZ[b]-rawXYZ[c],rawXYZ[b+1]-rawXYZ[c+1]),e3=Math.hypot(rawXYZ[c]-rawXYZ[a],rawXYZ[c+1]-rawXYZ[a+1]);if(Math.max(e1,e2,e3)<=edgeLimit)renderList.push(indices[i],indices[i+1],indices[i+2]);}var renderIdx=new Uint32Array(renderList),gl=this.gl;this.pb&&gl.deleteBuffer(this.pb);this.nb&&gl.deleteBuffer(this.nb);this.ab&&gl.deleteBuffer(this.ab);this.ib&&gl.deleteBuffer(this.ib);this.wb&&gl.deleteBuffer(this.wb);this.pb=gl.createBuffer();this.nb=gl.createBuffer();this.ab=gl.createBuffer();this.ib=gl.createBuffer();this.wb=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,renderIdx,gl.STATIC_DRAW);var edgeSet=new Set(),edgeList=[];for(i=0;i<indices.length;i+=3){var aa=indices[i],bb=indices[i+1],cc=indices[i+2],pairs=[[aa,bb],[bb,cc],[cc,aa]];for(var j=0;j<3;j++){var q=pairs[j],lo=q[0]<q[1]?q[0]:q[1],hi=q[0]<q[1]?q[1]:q[0],key=lo*n+hi;if(!edgeSet.has(key)){edgeSet.add(key);edgeList.push(lo,hi);}}}this.wireIdx=new Uint32Array(edgeList);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.wb);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,this.wireIdx,gl.STATIC_DRAW);this.ic=renderIdx.length;this.model={rawXYZ:rawXYZ,indices:indices,renderIdx:renderIdx,meta:meta,neighbors:this._buildNeighbors(n,renderIdx),displayXYZ:rawXYZ};this._updateDisplayBuffers(rawXYZ);if(reset)this.fit();};
  Topo3DEngine.prototype._computeAO=function(xyz){var n=xyz.length/3,ao=new Float32Array(n),srcN=new Float64Array(n*3),idx=this.model.renderIdx;for(var k=0;k<idx.length;k+=3){var ia=idx[k]*3,ib=idx[k+1]*3,ic=idx[k+2]*3,ux=xyz[ib]-xyz[ia],uy=xyz[ib+1]-xyz[ia+1],uz=xyz[ib+2]-xyz[ia+2],vx=xyz[ic]-xyz[ia],vy=xyz[ic+1]-xyz[ia+1],vz=xyz[ic+2]-xyz[ia+2],nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;srcN[ia]+=nx;srcN[ia+1]+=ny;srcN[ia+2]+=nz;srcN[ib]+=nx;srcN[ib+1]+=ny;srcN[ib+2]+=nz;srcN[ic]+=nx;srcN[ic+1]+=ny;srcN[ic+2]+=nz;}for(var i=0;i<n;i++){var q=i*3,l=Math.hypot(srcN[q],srcN[q+1],srcN[q+2])||1;srcN[q]/=l;srcN[q+1]/=l;srcN[q+2]/=l;var nb=this.model.neighbors[i];if(!nb.length){ao[i]=0;continue;}var sum=0,ws=0,ix=xyz[q],iy=xyz[q+1],iz=xyz[q+2];for(var j=0;j<nb.length;j++){var v=nb[j],r=v*3,dx=xyz[r]-ix,dy=xyz[r+1]-iy,dz=xyz[r+2]-iz,dist=Math.hypot(dx,dy)||1;if(Math.abs(srcN[q+2])<.12)continue;var pred=-(srcN[q]*dx+srcN[q+1]*dy)/srcN[q+2],res=dz-pred,occ=Math.max(0,Math.min(1,res/(dist*.55))),w=1/(1+dist*.001);sum+=occ*w;ws+=w;}ao[i]=ws?sum/ws:0;}for(var pass=0;pass<2;pass++){var next=new Float32Array(ao);for(i=0;i<n;i++){var nbs=this.model.neighbors[i];if(!nbs.length)continue;var sm=ao[i]*2,w2=2;for(j=0;j<nbs.length;j++){sm+=ao[nbs[j]];w2++;}next[i]=sm/w2;}ao.set(next);}return ao;};
  Topo3DEngine.prototype._updateDisplayBuffers=function(xyz){var m=this.model,b=m.meta.bounds,cx=(b.minX+b.maxX)/2,cy=(b.minY+b.maxY)/2,cz=(b.minZ+b.maxZ)/2,span=Math.max(b.maxX-b.minX,b.maxY-b.minY)||1,sx=1.65/span,sy=sx*this.zFactor,pos=new Float32Array(xyz.length);for(var i=0;i<xyz.length/3;i++){pos[i*3]=(xyz[i*3]-cx)*sx;pos[i*3+1]=(xyz[i*3+2]-cz)*sy;pos[i*3+2]=(xyz[i*3+1]-cy)*sx;}var normals=new Float32Array(pos.length),ao=this._computeAO(xyz);for(i=0;i<m.renderIdx.length;i+=3){var ia=m.renderIdx[i]*3,ib=m.renderIdx[i+1]*3,ic=m.renderIdx[i+2]*3,ax=pos[ib]-pos[ia],ay=pos[ib+1]-pos[ia+1],az=pos[ib+2]-pos[ia+2],bx=pos[ic]-pos[ia],by=pos[ic+1]-pos[ia+1],bz=pos[ic+2]-pos[ia+2],nx=ay*bz-az*by,ny=az*bx-ax*bz,nz=ax*by-ay*bx;[ia,ib,ic].forEach(function(j){normals[j]+=nx;normals[j+1]+=ny;normals[j+2]+=nz;});}for(i=0;i<normals.length;i+=3){var l=Math.hypot(normals[i],normals[i+1],normals[i+2])||1;normals[i]/=l;normals[i+1]/=l;normals[i+2]/=l;}var gl=this.gl;gl.bindBuffer(gl.ARRAY_BUFFER,this.pb);gl.bufferData(gl.ARRAY_BUFFER,pos,gl.STATIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,this.nb);gl.bufferData(gl.ARRAY_BUFFER,normals,gl.STATIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,this.ab);gl.bufferData(gl.ARRAY_BUFFER,ao,gl.STATIC_DRAW);m.displayXYZ=xyz;};
  Topo3DEngine.prototype._buildFromParsed=function(coords,triLines,name,strRecords,dtmRecords,invalidRefs){var used=Array.from(new Set(triLines.flat())),map=new Map(used.map(function(v,i){return [v,i];})),raw=new Float64Array(used.length*3),minX=Infinity,minY=Infinity,minZ=Infinity,maxX=-Infinity,maxY=-Infinity,maxZ=-Infinity;used.forEach(function(v,i){var p=coords.get(v);raw[i*3]=p[0];raw[i*3+1]=p[1];raw[i*3+2]=p[2];minX=Math.min(minX,p[0]);maxX=Math.max(maxX,p[0]);minY=Math.min(minY,p[1]);maxY=Math.max(maxY,p[1]);minZ=Math.min(minZ,p[2]);maxZ=Math.max(maxZ,p[2]);});var idx=new Uint32Array(triLines.length*3);triLines.forEach(function(t,i){idx[i*3]=map.get(t[0]);idx[i*3+1]=map.get(t[1]);idx[i*3+2]=map.get(t[2]);});var meta={version:1,name:name,triangles:triLines.length,bounds:{minX:minX,maxX:maxX,minY:minY,maxY:maxY,minZ:minZ,maxZ:maxZ}};meta.geometryAudit=this._audit(raw,idx);this._buildGPU(raw,idx,meta,true);this.onStatus('DTM siap · '+triLines.length.toLocaleString('id-ID')+' triangles');this.onReady({type:'dtm',meta:meta,strRecords:strRecords,dtmRecords:dtmRecords,invalidRefs:invalidRefs});return meta;};
  Topo3DEngine.prototype._sha256Hex=async function(bytes){
    if(global.crypto&&global.crypto.subtle){
      var digest=await global.crypto.subtle.digest('SHA-256',bytes);
      return Array.from(new Uint8Array(digest)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');
    }
    return '';
  };

  Topo3DEngine.prototype.loadDTMSTR=async function(dtmFile,strFile){try{guardTopoFileSize_(dtmFile,TOPO3D_RESOURCE_LIMITS.maxDtmBytes,'File DTM');guardTopoFileSize_(strFile,TOPO3D_RESOURCE_LIMITS.maxStrBytes,'File STR');await this.prepare();this.onStatus('Membaca DTM + STR secara lokal…');var str=await strFile.text(),dtm=await dtmFile.text(),sl=str.split(/\r?\n/),coords=new Map(),strRecords=0;for(var v=1;v+1<sl.length;v++){var raw=sl[v+1].trim();if(!raw)continue;if(/^END\b/i.test(raw))break;var p=raw.split(/[,\s]+/).filter(Boolean);if(p.length<4)continue;var x=Number(p[1]),y=Number(p[2]),z=Number(p[3]);if(!Number.isFinite(x)||!Number.isFinite(y)||!Number.isFinite(z))continue;strRecords++;guardTopoCount_(strRecords,TOPO3D_RESOURCE_LIMITS.maxVertices,'Jumlah vertex STR');coords.set(v,[x,y,z]);}var dl=dtm.split(/\r?\n/),triStartIndex=dl.findIndex(function(l){return /^TRISOLATION\b/i.test(l.trim());});if(triStartIndex<0)throw new Error('TRISOLATION section tidak ditemukan pada DTM');var triLines=[],dtmRecords=0,invalidRefs=0;for(var i=triStartIndex+1;i<dl.length;i++){var rr=dl[i].trim();if(!rr)continue;if(/^END\b/i.test(rr))break;var pp=rr.split(/[,\s]+/).filter(Boolean);if(pp.length<4)continue;var a=Number(pp[1]),b=Number(pp[2]),c=Number(pp[3]);if(![a,b,c].every(Number.isInteger))continue;dtmRecords++;guardTopoCount_(dtmRecords,TOPO3D_RESOURCE_LIMITS.maxTriangles,'Jumlah triangle DTM');if(coords.has(a)&&coords.has(b)&&coords.has(c)){triLines.push([a,b,c]);guardTopoCount_(triLines.length,TOPO3D_RESOURCE_LIMITS.maxTriangles,'Jumlah triangle valid');}else invalidRefs++;}if(!triLines.length)throw new Error('Tidak ada triangle valid. STR='+strRecords+', DTM='+dtmRecords+', invalid='+invalidRefs);this._sourcePackage={format:'DTM+STR',dtmName:dtmFile.name,strName:strFile.name,dtmText:dtm,strText:str};return this._buildFromParsed(coords,triLines,dtmFile.name.replace(/\.dtm$/i,''),strRecords,dtmRecords,invalidRefs);}catch(e){this.onError(e);throw e;}};

  Topo3DEngine.prototype.exportLTDtm=async function(options){
    options=options||{};
    if(!this.model)throw new Error('Belum ada data topografi untuk disimpan.');
    if(!this._sourcePackage||!this._sourcePackage.dtmText||!this._sourcePackage.strText)throw new Error('Source DTM + STR tidak tersedia. Import pasangan DTM + STR terlebih dahulu.');
    var enc=new TextEncoder();
    var dtmBytes=enc.encode(this._sourcePackage.dtmText),strBytes=enc.encode(this._sourcePackage.strText);
    var meta=Object.assign({},this.model.meta||{});
    meta.packageFormat='LITHODTM'; meta.packageVersion=2; meta.sourceFormat='DTM+STR'; meta.savedAt=new Date().toISOString();
    meta.dtmName=this._sourcePackage.dtmName; meta.strName=this._sourcePackage.strName;
    var manifest={format:'LITHODTM',packageVersion:2,sourceFormat:'DTM+STR',name:options.filename||meta.name||'Lithosite_Topografi',savedAt:meta.savedAt,dtmName:this._sourcePackage.dtmName,strName:this._sourcePackage.strName,dtmBytes:dtmBytes.byteLength,strBytes:strBytes.byteLength,geometry:{vertices:meta.vertices||this.model.rawXYZ.length/3,triangles:meta.triangles||this.model.indices.length/3},dtmSha256:await this._sha256Hex(dtmBytes),strSha256:await this._sha256Hex(strBytes)};
    var mb=enc.encode(JSON.stringify(manifest));
    var total=8+4+4+4+4+mb.byteLength+dtmBytes.byteLength+strBytes.byteLength;
    var buf=new ArrayBuffer(total),out=new Uint8Array(buf),dv=new DataView(buf),o=0;
    out.set(enc.encode('LITHODTM'),o);o+=8; dv.setUint32(o,2,true);o+=4; dv.setUint32(o,mb.byteLength,true);o+=4; dv.setUint32(o,dtmBytes.byteLength,true);o+=4; dv.setUint32(o,strBytes.byteLength,true);o+=4;
    out.set(mb,o);o+=mb.byteLength; out.set(dtmBytes,o);o+=dtmBytes.byteLength; out.set(strBytes,o);
    return {blob:new Blob([buf],{type:'application/octet-stream'}),meta:manifest,filename:(manifest.name||'Lithosite_Topografi').replace(/\.ltdtm$/i,'')+'.ltdtm'};
  };
  Topo3DEngine.prototype.loadLTDtm=async function(file){try{await this.prepare();this.onStatus('Membaca package Topografi…');var buf=await file.arrayBuffer(),bytes=new Uint8Array(buf),dv=new DataView(buf),dec=new TextDecoder();if(bytes.byteLength<12||bytes.byteLength>TOPO3D_RESOURCE_LIMITS.maxPackageBytes||dec.decode(bytes.subarray(0,8))!=='LITHODTM')throw new Error(bytes.byteLength>TOPO3D_RESOURCE_LIMITS.maxPackageBytes?'Package Topografi terlalu besar. Batas 128 MB.':'File .ltdtm tidak valid');var o=8,version=dv.getUint32(o,true);o+=4;if(version===2){if(bytes.byteLength<24)throw new Error('Package Topografi tidak lengkap');var ml=dv.getUint32(o,true);o+=4;var dl=dv.getUint32(o,true);o+=4;var sl=dv.getUint32(o,true);o+=4;if(ml<2||ml>bytes.byteLength||dl<1||sl<1||dl>TOPO3D_RESOURCE_LIMITS.maxDtmBytes||sl>TOPO3D_RESOURCE_LIMITS.maxStrBytes||o+ml+dl+sl>bytes.byteLength)throw new Error('Struktur/ukuran package Topografi tidak valid');var manifest=JSON.parse(dec.decode(bytes.subarray(o,o+ml)));o+=ml;var dtmBytes=bytes.slice(o,o+dl);o+=dl;var strBytes=bytes.slice(o,o+sl);var dtmSha=await this._sha256Hex(dtmBytes),strSha=await this._sha256Hex(strBytes);if(manifest.dtmSha256&&dtmSha&&manifest.dtmSha256!==dtmSha)throw new Error('Checksum DTM tidak cocok.');if(manifest.strSha256&&strSha&&manifest.strSha256!==strSha)throw new Error('Checksum STR tidak cocok.');var dtmName=manifest.dtmName||((manifest.name||'Lithosite_Topografi')+'.dtm'),strName=manifest.strName||((manifest.name||'Lithosite_Topografi')+'.str');var dtmFile=new File([dtmBytes],dtmName,{type:'text/plain'}),strFile=new File([strBytes],strName,{type:'text/plain'});this.onStatus('Memulihkan pasangan DTM + STR…');return await this.loadDTMSTR(dtmFile,strFile);}if(version!==1)throw new Error('Versi DTM package tidak didukung');var vc=dv.getUint32(o,true);o+=4,icount=dv.getUint32(o,true);o+=4,ml=dv.getUint32(o,true);o+=4,meta=JSON.parse(dec.decode(bytes.subarray(o,o+ml)));o+=ml;if(vc<1||vc>TOPO3D_RESOURCE_LIMITS.maxVertices||icount<3||icount>TOPO3D_RESOURCE_LIMITS.maxTriangles*3||o+vc*24+icount*4>bytes.byteLength)throw new Error('Ukuran geometry package tidak valid atau melebihi batas Topo3D');var xyz=new Float64Array(vc*3);new Uint8Array(xyz.buffer).set(bytes.subarray(o,o+xyz.byteLength));o+=xyz.byteLength;var idx=new Uint32Array(icount);new Uint8Array(idx.buffer).set(bytes.subarray(o,o+idx.byteLength));if(idx.length%3)throw new Error('Triangle index tidak valid');this._sourcePackage=null;this._buildGPU(xyz,idx,meta,true);this.onStatus('Package geometry siap · '+meta.triangles.toLocaleString('id-ID')+' triangles');this.onReady({type:'ltdtm-v1',meta:meta});return meta;}catch(e){this.onError(e);throw e;}};
  Topo3DEngine.prototype.loadFiles=async function(files){var fs=Array.from(files||[]),ltdtm=fs.find(function(f){return /\.ltdtm$/i.test(f.name);});if(ltdtm)return this.loadLTDtm(ltdtm);var dtm=fs.find(function(f){return /\.dtm$/i.test(f.name);}),str=fs.find(function(f){return /\.str$/i.test(f.name);});if(!dtm||!str)throw new Error('Pilih .ltdtm, atau pasangan .dtm + .str.');return this.loadDTMSTR(dtm,str);};
  Topo3DEngine.prototype.fit=function(){if(!this.model)return;this.angleX=this.view==='top'?-1.48:.44;this.angleY=this.view==='top'?0:-.38;this.panX=this.panY=0;this.zoom=1;};
  Topo3DEngine.prototype.setView=function(view){if(view!=='top'&&view!=='3d')return;this.view=view;this.fit();};
  Topo3DEngine.prototype.setMode=function(mode){if(mode==='shaded'||mode==='elevation'||mode==='wire')this.mode=mode;};
  Topo3DEngine.prototype.setOptions=function(o){o=o||{};if(o.zFactor!=null)this.zFactor=Number(o.zFactor);if(o.gapGuard!=null)this.gapGuard=!!o.gapGuard;if(o.meshOverlay!=null)this.meshOverlay=!!o.meshOverlay;if(o.reliefOn!=null)this.reliefOn=!!o.reliefOn;if(o.tintOn!=null)this.tintOn=!!o.tintOn;if(o.aoStrength!=null)this.aoStrength=Number(o.aoStrength);if(o.reliefStrength!=null)this.reliefStrength=Number(o.reliefStrength);if(o.meshAlpha!=null)this.meshAlpha=Number(o.meshAlpha);if(o.smoothStrength!=null)this.smoothStrength=Number(o.smoothStrength);if(o.smoothIterations!=null)this.smoothIterations=Math.max(1,Number(o.smoothIterations));if(this.model)this._buildGPU(this.model.rawXYZ,this.model.indices,this.model.meta,false);};
  Topo3DEngine.prototype.projectCoordinate=function(x,y,z){
    if(!this.model||!this.canvas)return null;
    x=Number(x); y=Number(y); z=Number(z);
    if(!Number.isFinite(x)||!Number.isFinite(y))return null;
    var b=this.model.meta&&this.model.meta.bounds;
    if(!b)return null;
    var padX=Math.max(1e-6,(b.maxX-b.minX)*0.015),padY=Math.max(1e-6,(b.maxY-b.minY)*0.015);
    if(x<b.minX-padX||x>b.maxX+padX||y<b.minY-padY||y>b.maxY+padY)return null;
    if(!Number.isFinite(z)){
      var raw=this.model.rawXYZ,best=-1,bestD=Infinity;
      for(var i=0;i<raw.length;i+=3){var dx=raw[i]-x,dy=raw[i+1]-y,d=dx*dx+dy*dy;if(d<bestD){bestD=d;best=i;}}
      if(best<0)return null;
      z=raw[best+2];
    }
    var span=Math.max(b.maxX-b.minX,b.maxY-b.minY)||1,cx=(b.minX+b.maxX)/2,cy=(b.minY+b.maxY)/2,cz=(b.minZ+b.maxZ)/2;
    var sx=1.65/span,sy=sx*this.zFactor;
    var v=[(x-cx)*sx,(z-cz)*sy,(y-cy)*sx];
    var P=this._persp(.82,this.canvas.width/Math.max(1,this.canvas.height),.05,20),T=this._tr(this.panX,this.panY,-3.15),RX=this._rx(this.angleX),RY=this._ry(this.angleY),S=this._sc(this.zoom),M=this._matMul(T,this._matMul(this._matMul(RX,RY),S)),MVP=this._matMul(P,M);
    // Keep the full clip-space vector. The previous implementation treated
    // clip-W as NDC-Z, which could mark valid TP coordinates as outside and
    // suppress every flag marker/label.
    var clipX=MVP[0]*v[0]+MVP[4]*v[1]+MVP[8]*v[2]+MVP[12];
    var clipY=MVP[1]*v[0]+MVP[5]*v[1]+MVP[9]*v[2]+MVP[13];
    var clipZ=MVP[2]*v[0]+MVP[6]*v[1]+MVP[10]*v[2]+MVP[14];
    var clipW=MVP[3]*v[0]+MVP[7]*v[1]+MVP[11]*v[2]+MVP[15];
    if(!Number.isFinite(clipW)||clipW<=0)return null;
    var ndcX=clipX/clipW,ndcY=clipY/clipW,ndcZ=clipZ/clipW;
    return {x:(ndcX*.5+.5)*this.canvas.clientWidth,y:(1-(ndcY*.5+.5))*this.canvas.clientHeight,depth:ndcZ,inside:ndcX>=-1.25&&ndcX<=1.25&&ndcY>=-1.25&&ndcY<=1.25&&ndcZ>=-1&&ndcZ<=1};
  };
  Topo3DEngine.prototype.focusCoordinate=function(x,y,z){
    if(!this.model||!this.canvas)return false;
    var targetX=this.canvas.clientWidth/2,targetY=this.canvas.clientHeight/2;
    var p=this.projectCoordinate(x,y,z);
    if(!p)return false;
    var basePanX=this.panX,basePanY=this.panY;
    this.panX=basePanX+0.01;
    var px=this.projectCoordinate(x,y,z);
    this.panX=basePanX;
    this.panY=basePanY+0.01;
    var py=this.projectCoordinate(x,y,z);
    this.panY=basePanY;
    var dx=px&&Number.isFinite(px.x)?px.x-p.x:0;
    var dy=py&&Number.isFinite(py.y)?py.y-p.y:0;
    if(Math.abs(dx)>1e-6)this.panX=basePanX+(targetX-p.x)/dx*0.01;
    if(Math.abs(dy)>1e-6)this.panY=basePanY+(targetY-p.y)/dy*0.01;
    return true;
  };
  Topo3DEngine.prototype.pickCoordinate=function(screenX,screenY,maxDistance){
    if(!this.model||!this.canvas)return null;
    screenX=Number(screenX);screenY=Number(screenY);
    maxDistance=Number.isFinite(Number(maxDistance))?Number(maxDistance):18;
    if(!Number.isFinite(screenX)||!Number.isFinite(screenY)||maxDistance<=0)return null;
    var raw=this.model.rawXYZ,best=null,bestD=maxDistance*maxDistance;
    for(var i=0;i<raw.length;i+=3){
      var p=this.projectCoordinate(raw[i],raw[i+1],raw[i+2]);
      if(!p||!p.inside)continue;
      var dx=p.x-screenX,dy=p.y-screenY,d=dx*dx+dy*dy;
      if(d<=bestD){bestD=d;best={easting:raw[i],northing:raw[i+1],elevation:raw[i+2],screenX:p.x,screenY:p.y,distancePixels:Math.sqrt(d)};}
    }
    return best;
  };
  Topo3DEngine.prototype.getState=function(){return {prepared:this.prepared,ready:!!this.model,view:this.view,mode:this.mode,meta:this.model?this.model.meta:null};};
  Topo3DEngine.prototype._pointerDown=function(e){this.activePointers.set(e.pointerId,{x:e.clientX,y:e.clientY});this.canvas.setPointerCapture(e.pointerId);if(this.activePointers.size===1){this.dragging=true;this.lastX=e.clientX;this.lastY=e.clientY;}if(this.activePointers.size===2){var a=Array.from(this.activePointers.values());this.pinchStart=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);this.pinchZoom=this.zoom;}};
  Topo3DEngine.prototype._pointerMove=function(e){if(!this.activePointers.has(e.pointerId))return;this.activePointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(this.activePointers.size===2){var a=Array.from(this.activePointers.values()),d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(this.pinchStart>0)this.zoom=Math.max(.45,Math.min(4,this.pinchZoom*(d/this.pinchStart)));return;}if(!this.dragging)return;var dx=e.clientX-this.lastX,dy=e.clientY-this.lastY;this.lastX=e.clientX;this.lastY=e.clientY;if(e.shiftKey){this.panX+=dx*.0025;this.panY-=dy*.0025;}else{this.angleY+=dx*.006;this.angleX+=dy*.006;this.angleX=Math.max(-1.50,Math.min(1.50,this.angleX));}};
  Topo3DEngine.prototype._pointerUp=function(e){this.activePointers.delete(e.pointerId);if(this.activePointers.size<2)this.pinchStart=0;if(this.activePointers.size===0)this.dragging=false;};
  Topo3DEngine.prototype._wheel=function(e){e.preventDefault();this.zoom*=Math.exp(-e.deltaY*.001);this.zoom=Math.max(.45,Math.min(4,this.zoom));};
  Topo3DEngine.prototype.clear=function(){var gl=this.gl;if(gl){[this.pb,this.nb,this.ab,this.ib,this.wb].forEach(function(b){if(b)gl.deleteBuffer(b);});}this.pb=this.nb=this.ab=this.ib=this.wb=null;this.wireIdx=null;this.ic=0;this.model=null;this._sourcePackage=null;this.angleX=.44;this.angleY=-.38;this.zoom=1;this.panX=0;this.panY=0;this.view='3d';this.mode='shaded';this.onStatus('Topography cleared. Menunggu data topografi…');};
  Topo3DEngine.prototype.destroy=function(){this.destroyed=true;if(this.raf)cancelAnimationFrame(this.raf);this.raf=null;window.removeEventListener('resize',this._boundResize);if(this.canvas){this.canvas.removeEventListener('pointerdown',this._boundPointerDown);this.canvas.removeEventListener('pointermove',this._boundPointerMove);this.canvas.removeEventListener('pointerup',this._boundPointerUp);this.canvas.removeEventListener('pointercancel',this._boundPointerUp);this.canvas.removeEventListener('wheel',this._boundWheel);}if(this.gl){[this.pb,this.nb,this.ab,this.ib,this.wb].forEach(function(b){if(b)this.gl.deleteBuffer(b);},this);if(this.prog)this.gl.deleteProgram(this.prog);}this.model=null;this.gl=null;this.prepared=false;};

  global.LithositeTopo3D={create:function(options){return new Topo3DEngine(options||{});},version:'1.0.0',baseline:'V23.2'};
})(window);
