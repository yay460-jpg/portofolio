# Baseline

## Current locked baseline

**Status:** LOCKED  
**Product:** Lithosite Mine Services  
**Canonical artifact:** `Artifacts/Mine-Services-Operations.html`  
**Schema:** A.3  
**Database:** `Database/Mine-Services-Database-A3.xlsx`

See [V40 Baseline Lock](./V40-Baseline-Lock.md) for the release decision, evidence, commit, and explicitly deferred gates.

## Historical baselines

Earlier baseline lock documents remain in this directory as historical records only. Their runtime artifacts and version-specific filenames are not kept in the active Artifacts folder.

## Active development workspace

<<<<<<< HEAD
The active development workspace is `v40-workspace`, copied from the locked V39 state. New features and layout changes must be made in that workspace, not in the closed V39 baseline. See `../V40-Workspace-Initialization.md` for its scope and initial backlog.
=======
The next development workspace must be created from the latest locked baseline after promotion to `main`. Runtime filenames remain version-neutral; version history belongs in Documentation.
>>>>>>> f3762ae835475db05f7ba209a1c76b0f24c3dc5a

Runtime operations must never overwrite the baseline or mutate the operational database without authorization.
