# Version History

Version-specific implementation summaries and historical release records live in this folder.

<<<<<<< HEAD
- [V39 Baseline Lock](./Baseline/V39-Baseline-Lock.md) — current locked Mine Services baseline; V38 is superseded.
- [V39 — Workflow and Maintenance Enhancements](./V39-Workflow-and-Maintenance-Enhancements.md) — closed version summary, Evidence integrations, Work Front map feedback, and verified final test result.
- [V40 — Workspace Initialization](./V40-Workspace-Initialization.md) — active development workspace copied from V39; Plan vs Actual cards remain the initial backlog.
=======
- [V40 Baseline Lock](./Baseline/V40-Baseline-Lock.md) — latest locked baseline and validation record.
- [V39 Baseline Lock](./Baseline/V39-Baseline-Lock.md) — superseded historical baseline record.
- [V39 — Workflow and Maintenance Enhancements](./V39-Workflow-and-Maintenance-Enhancements.md) — historical release summary.
- [V40 — Workspace Initialization](./V40-Workspace-Initialization.md) — historical workspace lineage and release-gate notes.
>>>>>>> f3762ae835475db05f7ba209a1c76b0f24c3dc5a

Do not place version-specific runtime artifacts in active folders. Keep current contracts and the global Target vs Actual decision reminder version-neutral.
